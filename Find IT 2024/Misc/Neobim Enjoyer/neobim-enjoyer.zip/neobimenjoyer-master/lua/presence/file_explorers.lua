-- Different neovim file explorer names keyed by filetype or buffer name
return {
	["NvimTree"] = "NvimTree",
	["NERD_tree_"] = "NERDTree",
	["[defx] default-"] = "Defx",
	["netrw"] = "Netrw",
	["TelescopePrompt"] = "Telescope",
	["neo-tree"] = "Neotree",
	["fern"] = "Fern",
}

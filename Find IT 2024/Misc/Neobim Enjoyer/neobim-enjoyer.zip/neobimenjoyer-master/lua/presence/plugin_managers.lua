-- Different plugin manager names
return {
	["packer"] = "packer",
	["vim-plug"] = "vim-plug",
	["lazy"] = "lazy",
}
